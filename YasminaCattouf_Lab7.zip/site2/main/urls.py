from django.urls import path
from . import views

app_name = "main"   

urlpatterns = [

    path("", views.main, name="main"),

    path("create/", views.homepage, name="homepage"),
    path("edit/<str:name>", views.edit, name="edit"),
    path("delete/<str:name>/", views.delete, name="delete"),

#######################

    path("search/", views.search, name="search"),
    path("show/", views.showall, name="view"),
    path("show/name.<str:name>", views.showname, name="showname"),
    path("show/tel1.<str:tel>", views.showtel, name="showtel"),
    path("show/profession.<str:profession>", views.showprof, name="showprof"),
    path("show/compare.<str:n1>/<str:n2>", views.compare, name="compare"),



   
    
    
    
    
    


  
]